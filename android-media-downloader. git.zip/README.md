# Media Downloader - Android (Honor / any Android 10+)

## APK বানানোর নিয়ম (PC-তে, একবার)
1. Android Studio (Koala বা নতুন) ইনস্টল করুন: https://developer.android.com/studio
2. এই zip খুলুন → Android Studio-তে **Open** → ফোল্ডারটি সিলেক্ট করুন।
3. Gradle Sync শেষ হতে দিন (ইন্টারনেট লাগবে)।
4. মেনু: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
5. APK পাবেন: `app/build/outputs/apk/debug/app-debug.apk`
6. ফোনে পাঠান (USB/Drive) → খুলে ইনস্টল করুন
   (Settings-এ "Install unknown apps" চালু করতে হতে পারে)।

## ব্যবহার
- লিংক পেস্ট করুন, বা ব্রাউজার/অ্যাপ থেকে Share → Media Downloader।
- ফাইল সেভ হয় `Downloads/MediaDownloader` ফোল্ডারে।

## সমস্যা হলে
- Sync error: `app/build.gradle`-এ youtubedl-android ভার্সন (0.17.2) নতুন ভার্সনে বদলান।
- ডাউনলোড হঠাৎ কাজ না করলে সাইট বদলেছে - ভার্সন আপডেট করে নতুন APK বানান (yt-dlp আপডেট হয়)।
