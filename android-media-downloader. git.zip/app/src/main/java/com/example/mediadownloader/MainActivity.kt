package com.example.mediadownloader

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.Future

class MainActivity : Activity() {

    private lateinit var web: WebView
    private val pool = Executors.newCachedThreadPool()
    private var initTask: Future<*>? = null
    private var sharedUrl: String? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Prepare yt-dlp + ffmpeg in the background (first launch takes a few seconds)
        initTask = Executors.newSingleThreadExecutor().submit(Runnable {
            YoutubeDL.getInstance().init(applicationContext)
            FFmpeg.getInstance().init(applicationContext)
        })

        web = WebView(this)
        setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                pushSharedUrl()
            }
        }
        handleIntent(intent)
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
        pushSharedUrl()
    }

    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) {
            val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
            sharedUrl = Regex("https?://\\S+").find(text)?.value
        }
    }

    private fun pushSharedUrl() {
        sharedUrl?.let { call("setUrl", it) }
    }

    private fun js(code: String) = runOnUiThread { web.evaluateJavascript(code, null) }

    private fun call(fn: String, vararg args: String) =
        js("window.$fn(" + args.joinToString(",") { JSONObject.quote(it) } + ")")

    private fun errMsg(e: Throwable): String = (e.cause ?: e).message ?: "Error"

    private fun saveToDownloads(file: File) {
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.extension)
            ?: "application/octet-stream"
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, file.name)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MediaDownloader")
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw Exception("Cannot create file in Downloads")
        contentResolver.openOutputStream(uri)?.use { out ->
            file.inputStream().use { it.copyTo(out) }
        } ?: throw Exception("Cannot write file")
    }

    inner class Bridge {

        @JavascriptInterface
        fun getInfo(url: String) {
            pool.execute {
                try {
                    initTask?.get()
                    val info = YoutubeDL.getInstance().getInfo(url)
                    val heights = info.formats?.map { it.height }?.filter { it > 0 }
                        ?.distinct()?.sortedDescending() ?: emptyList()
                    val o = JSONObject()
                        .put("title", info.title ?: "")
                        .put("thumbnail", info.thumbnail ?: "")
                        .put("duration", info.duration)
                        .put("uploader", info.uploader ?: "")
                        .put("heights", JSONArray(heights))
                    call("onInfo", o.toString())
                } catch (e: Exception) {
                    call("onError", errMsg(e))
                }
            }
        }

        @JavascriptInterface
        fun download(url: String, type: String, fmt: String, quality: String) {
            pool.execute {
                try {
                    initTask?.get()
                    if (quality != "best" && !quality.matches(Regex("\\d{3,4}"))) throw Exception("Invalid quality")
                    if (!fmt.matches(Regex("[a-z0-9]{3,5}"))) throw Exception("Invalid format")

                    val dir = File(cacheDir, "dl/${System.currentTimeMillis()}").apply { mkdirs() }
                    val req = YoutubeDLRequest(url)
                    req.addOption("--no-playlist")
                    req.addOption("-o", dir.absolutePath + "/%(title).80s.%(ext)s")
                    if (type == "video") {
                        val sel = if (quality == "best") "bv*+ba/b"
                        else "bv*[height<=$quality]+ba/b[height<=$quality]/b"
                        req.addOption("-f", sel)
                        req.addOption("--merge-output-format", fmt)
                    } else {
                        req.addOption("-x")
                        req.addOption("--audio-format", fmt)
                        req.addOption("--audio-quality", "0")
                    }

                    YoutubeDL.getInstance().execute(req, null) { progress, _, _ ->
                        call("onProgress", progress.toString())
                    }

                    val file = dir.listFiles()
                        ?.filter { it.isFile && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") }
                        ?.maxByOrNull { it.lastModified() }
                        ?: throw Exception("No file produced")
                    saveToDownloads(file)
                    dir.deleteRecursively()
                    call("onDone", file.name)
                } catch (e: Exception) {
                    call("onError", errMsg(e))
                }
            }
        }
    }
}
